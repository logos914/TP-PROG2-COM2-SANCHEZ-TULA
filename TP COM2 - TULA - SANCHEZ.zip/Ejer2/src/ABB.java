
@SuppressWarnings("hiding")
public class ABB<Integer> extends AB<Integer> {

	// Este insertar fue modificado para que el �rbol sea binario de busqueda
	@Override
	protected void insertar(Nodo<Integer> padre, Nodo<Integer> nuevo) {
		if (padre.izq == null && (int) padre.info > (int) nuevo.info) {
			padre.izq = nuevo;
		} else if (padre.der == null && (int) padre.info < (int) nuevo.info) {
			padre.der = nuevo;
		}

		else {

			if ((int) padre.info > (int) nuevo.info) {
				insertar(padre.izq, nuevo);
			} else {
				insertar(padre.der, nuevo);
			}

		}
	}

	@Override
	public String toString() {

		if (this.raiz.izq != null && this.raiz.der != null) {
			return "\n     " + this.raiz.info.toString() + "\n ( " + this.raiz.izq.info.toString() + "  "
					+ this.raiz.der.info.toString() + " )\n" + aCadena(this.raiz.izq) + aCadena(this.raiz.der);
		} else if (this.raiz.izq == null && this.raiz.der != null) {
			return "\n     " + this.raiz.info.toString() + "\n (    " + this.raiz.der.info.toString() + " )\n"
					+ aCadena(this.raiz.der);
		}

		else if (this.raiz.izq != null && this.raiz.der == null) {
			return "\n     " + this.raiz.info.toString() + "\n ( " + this.raiz.izq.info.toString() + "    )\n"
					+ aCadena(this.raiz.izq);
		} else {
			return "\n     " + this.raiz.info.toString() + "\n(    )\n";
		}

	}

	private String aCadena(Nodo<Integer> nodo) {

		if (nodo.izq != null && nodo.der != null) {
			return "\n     " + nodo.info.toString() + "\n" + "( " + nodo.izq.info.toString() + " "
					+ nodo.der.info.toString() + " )\n" + aCadena(nodo.izq) + " " + aCadena(nodo.der);
		} else if (nodo.izq != null && nodo.der == null) {
			return "\n     " + nodo.info.toString() + "\n" + " ( " + nodo.izq.info.toString() + "     )\n"
					+ aCadena(nodo.izq) + " ";
		} else if (nodo.izq == null && nodo.der != null) {
			return "\n     " + nodo.info.toString() + "\n" + " (     " + nodo.der.info.toString() + " )\n" + "  "
					+ aCadena(nodo.der);
		} else {
			return "\n     " + nodo.info.toString() + "\n (       )\n";
		}

	}

	public boolean balanceado() {

		if (this.raiz == null) {
			return true;
		} else {
			return balanceado(this.raiz);
		}

	}

	protected boolean balanceado(Nodo<Integer> nodo) {
		boolean acumulador = true;
		int alturaIzquierda = 0;
		int alturaDerecha = 0;

		if (nodo.der != null) {
			alturaDerecha = altura(nodo.der);
			acumulador = acumulador && balanceado(nodo.der);

		}

		if (nodo.izq != null) {
			alturaIzquierda = altura(nodo.izq);
			acumulador = acumulador && balanceado(nodo.izq);
		}

		int resta = alturaIzquierda - alturaDerecha;

		if (resta < 0) {
			// resta + resta es cero. + resta es el absoluto o m�dulo (en caso de ser
			// negativo)
			resta = resta + resta + resta;
		}

		acumulador = acumulador && resta <= 1;
		return acumulador;
	}

	public void rebalancear() {
		while (!this.balanceado()) {
			System.out.print(this.toString());
			if (this.raiz != null) {

				if (altura(this.raiz.izq) - altura(this.raiz.der) > 2) {

					this.raiz = recambioDerecha(this.raiz);

				} else if (altura(this.raiz.izq) - altura(this.raiz.der) < -2) {
				
					this.raiz = recambioIzquierda(this.raiz);

				}

				else if (altura(this.raiz.izq) - altura(this.raiz.der) == 2) {
					if (altura(this.raiz) == 3) {
						
						this.raiz = recambioDerecha(this.raiz);
					} else {
						
						this.raiz.izq = this.balancear(this.raiz.izq);
					}
					

				} else if (altura(this.raiz.izq) - altura(this.raiz.der) == -2) {
					if (altura(this.raiz) == 3) {
						this.raiz = recambioIzquierda(this.raiz);
					} else {
						this.raiz.der = this.balancear(this.raiz.der);
					}
					
				}
			}
		}
	}

	private Nodo<Integer> balancear(Nodo<Integer> nodo) {

		if (altura(nodo.izq) - altura(nodo.der) > 2) {

			nodo.izq = balancear(nodo.izq);

		} else if (altura(nodo.izq) - altura(nodo.der) < -2) {

			nodo.der = balancear(nodo.der);
		}

		else if (altura(nodo.izq) - altura(nodo.der) == -2) {
			nodo = recambioIzquierda(nodo);

		}

		else if (altura(nodo.izq) - altura(nodo.der) == 2) {
			nodo = recambioDerecha(nodo);
		}

		return nodo;
	}

	private Nodo<Integer> recambioIzquierda(Nodo<Integer> nodo) {

		Nodo<Integer> nodoTemporal = nodo;

		Nodo<Integer> nodoTemporalHijo = nodo.der.izq;

		nodo = nodoTemporal.der;

		nodo.izq = nodoTemporal;

		nodo.izq.der = null;

		if (nodoTemporalHijo != null) {
			insertar(this.raiz, nodoTemporalHijo);
		}

		return nodo;

	}

	private Nodo<Integer> recambioDerecha(Nodo<Integer> nodo) {

		Nodo<Integer> nodoTemporal = nodo;
		Nodo<Integer> nodoTemporalHijo = nodo.izq.der;

		nodo = nodoTemporal.izq;

		nodo.der = nodoTemporal;

		nodo.der.izq = null;

		if (nodoTemporalHijo != null) {
			insertar(this.raiz, nodoTemporalHijo);
		}

		return nodo;

	}

}
