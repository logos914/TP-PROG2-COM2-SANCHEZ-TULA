import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestEj2Test_nuestro {

	ABB<Integer> abDesbalanceado;

	@Before
	public void setUp() throws Exception {
		abDesbalanceado = new ABB<Integer>();
		abDesbalanceado.insertar(1);
		abDesbalanceado.insertar(3);
		abDesbalanceado.insertar(0);
		abDesbalanceado.insertar(5);
		abDesbalanceado.insertar(2);
		abDesbalanceado.insertar(7);
		abDesbalanceado.insertar(8);

	}
	
	@Test
	public void testRebalancear() {
		System.out.print(abDesbalanceado.toString());
		abDesbalanceado.rebalancear();
		
		System.out.print("Deberia estar balanceado ya");
		System.out.print(abDesbalanceado.toString());
		assertTrue(abDesbalanceado.balanceado());
	}

	@Test
	public void testRebalancear() {
		System.out.print(abDesbalanceado.toString());
		abDesbalanceado.rebalancear();
		
		System.out.print("Deberia estar balanceado ya");
		System.out.print(abDesbalanceado.toString());
		assertTrue(abDesbalanceado.balanceado());
	}
		

}
